import React from 'react';

interface ProgressBarProps {
  current: number;
  max: number;
  colorClass: string;
  label?: string;
  showValue?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ current, max, colorClass, label, showValue = true }) => {
  const percentage = Math.min(100, Math.max(0, (current / max) * 100));

  return (
    <div className="w-full mb-2">
      <div className="flex justify-between text-xs mb-1 font-bold text-slate-300">
        {label && <span>{label}</span>}
        {showValue && <span>{current} / {max}</span>}
      </div>
      <div className="h-2.5 w-full bg-slate-800 rounded-full border border-slate-700/50 shadow-inner overflow-hidden">
        <div 
          className={`h-full rounded-full transition-all duration-500 ease-out shadow-[0_0_8px_rgba(255,255,255,0.3)] ${colorClass}`} 
          style={{ width: `${percentage}%` }}
        >
          {/* Subtle stripe effect */}
          <div className="w-full h-full bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[length:10px_10px]"></div>
        </div>
      </div>
    </div>
  );
};
