import React from 'react';
import * as Lucide from 'lucide-react';

export const SettingsView: React.FC = () => {
  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-6 shadow-lg">
        <h2 className="text-2xl font-cinzel text-slate-200 mb-6 flex items-center gap-2">
            <Lucide.Settings size={28} /> 系统设置
        </h2>
        
        <div className="space-y-6">
            <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded border border-slate-700/50">
                <div>
                    <h4 className="font-bold text-slate-300">自动刷新</h4>
                    <p className="text-xs text-slate-500">检测到新回复时自动更新变量</p>
                </div>
                <div className="w-12 h-6 bg-blue-600 rounded-full relative cursor-pointer">
                    <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full"></div>
                </div>
            </div>

            <div className="flex items-center justify-between p-4 bg-slate-800/50 rounded border border-slate-700/50">
                <div>
                    <h4 className="font-bold text-slate-300">显示详细骰子日志</h4>
                    <p className="text-xs text-slate-500">在状态栏显示技能检定细节</p>
                </div>
                <div className="w-12 h-6 bg-slate-700 rounded-full relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-slate-400 rounded-full"></div>
                </div>
            </div>

            <div className="p-4 bg-slate-950 rounded border border-slate-800">
                <h4 className="font-bold text-red-400 mb-2 flex items-center gap-2"><Lucide.AlertTriangle size={16}/> 调试信息</h4>
                <p className="text-xs text-slate-600 font-mono break-all">
                    Data Source: Mock MVU Provider<br/>
                    Version: v1.0.0-React<br/>
                    UUID: 01a32146-05e0-460a-8db1-6562ee4155e9
                </p>
            </div>
        </div>
      </div>
    </div>
  );
};
