import React from 'react';
import { StatData } from '../../types';
import * as Lucide from 'lucide-react';

interface TerritoryViewProps {
  data: StatData;
}

export const TerritoryView: React.FC<TerritoryViewProps> = ({ data }) => {
  const assets = data.主角.资产 || {};
  const hasAssets = Object.keys(assets).length > 0;

  return (
    <div className="animate-fadeIn">
      <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-6 shadow-lg mb-6">
         <h2 className="text-2xl font-cinzel text-amber-500 mb-2 flex items-center gap-2">
            <Lucide.Castle size={28} /> 领地与资产
         </h2>
         <p className="text-slate-400">管理你所拥有的地产、店铺或特殊设施。</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hasAssets ? Object.entries(assets).map(([key, asset]) => (
           <div key={key} className="bg-slate-800/60 border border-slate-600 rounded-lg overflow-hidden group hover:border-amber-500/50 transition-colors">
              <div className="bg-slate-950/50 p-4 border-b border-slate-700 flex justify-between items-center">
                 <h3 className="font-bold text-lg text-slate-200">{asset.名称 || key}</h3>
                 <span className="text-xs bg-amber-900/30 text-amber-300 border border-amber-800/50 px-2 py-1 rounded flex items-center gap-1">
                    <Lucide.MapPin size={12}/> {asset.位置}
                 </span>
              </div>
              <div className="p-4 space-y-4">
                 <div>
                    <h4 className="text-xs font-bold text-slate-500 uppercase mb-1">整体介绍</h4>
                    <p className="text-sm text-slate-300 leading-relaxed">{asset.整体介绍 || '暂无描述'}</p>
                 </div>
                 {asset.内部结构布局 && (
                    <div className="bg-slate-900/50 p-3 rounded border border-slate-700/30">
                        <h4 className="text-xs font-bold text-slate-500 uppercase mb-1 flex items-center gap-1"><Lucide.Layout size={12}/> 内部布局</h4>
                        <p className="text-xs text-slate-400 font-mono">{asset.内部结构布局}</p>
                    </div>
                 )}
              </div>
           </div>
        )) : (
            <div className="col-span-full py-12 text-center border-2 border-dashed border-slate-700 rounded-lg">
                <Lucide.Tent size={48} className="mx-auto text-slate-600 mb-4" />
                <h3 className="text-lg font-bold text-slate-500">名下暂无资产</h3>
                <p className="text-slate-600 text-sm">在冒险中获得地契或购买房产后在此显示。</p>
            </div>
        )}
      </div>
    </div>
  );
};
