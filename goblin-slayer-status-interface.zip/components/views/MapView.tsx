import React, { useEffect } from 'react';
import { MapContainer, ImageOverlay, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import { StatData } from '../../types';

// Fix for default leaflet marker icons in React
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

// Custom Icons
const playerIcon = new L.Icon({
    iconUrl: 'https://files.catbox.moe/euux9v.png',
    iconSize: [48, 48],
    iconAnchor: [24, 24],
});

const combatIcon = new L.Icon({ iconUrl: 'https://s21.ax1x.com/2025/10/15/pVqAkFI.png', iconSize: [32, 32] });
const transportIcon = new L.Icon({ iconUrl: 'https://s21.ax1x.com/2025/10/15/pVqAPwd.png', iconSize: [32, 32] });
const exploreIcon = new L.Icon({ iconUrl: 'https://s21.ax1x.com/2025/10/15/pVqACeH.png', iconSize: [32, 32] });
const defaultWPIcon = new L.Icon({ iconUrl: 'https://s21.ax1x.com/2025/10/15/pVqASyD.png', iconSize: [32, 32] });

interface MapViewProps {
  data: StatData;
}

const IMAGE_WIDTH = 2695;
const IMAGE_HEIGHT = 1840;
const MAP_URL = 'https://files.catbox.moe/afahhd.png';

// Coordinate flip helper as per script logic: Leaflet (0,0) is top-left, Game Y might be inverted relative to image
const flipY = (y: number) => IMAGE_HEIGHT - y;

const MapController = () => {
   const map = useMap();
   useEffect(() => {
     // Fit bounds initially
     const bounds: L.LatLngBoundsExpression = [[0, 0], [IMAGE_HEIGHT, IMAGE_WIDTH]];
     map.fitBounds(bounds);
   }, [map]);
   return null;
};

export const MapView: React.FC<MapViewProps> = ({ data }) => {
  const playerPos = data.主角.坐标 || { x: 0, y: 0 };
  const waypoints = data.地图位标 || {};
  const bounds: L.LatLngBoundsExpression = [[0, 0], [IMAGE_HEIGHT, IMAGE_WIDTH]];

  const getWPIcon = (type: string) => {
    if (type.includes('战斗') || type.includes('讨伐')) return combatIcon;
    if (type.includes('护卫') || type.includes('运输')) return transportIcon;
    if (type.includes('探索') || type.includes('采集')) return exploreIcon;
    return defaultWPIcon;
  };

  return (
    <div className="h-[600px] w-full rounded-lg overflow-hidden border border-slate-700 shadow-2xl relative bg-black animate-fadeIn">
      <MapContainer 
        crs={L.CRS.Simple} 
        bounds={bounds} 
        center={[flipY(playerPos.y), playerPos.x]} 
        zoom={-1} 
        minZoom={-2}
        style={{ height: '100%', width: '100%', background: '#0f172a' }}
      >
        <ImageOverlay url={MAP_URL} bounds={bounds} />
        <MapController />

        {/* Player Marker */}
        <Marker position={[flipY(playerPos.y), playerPos.x]} icon={playerIcon} zIndexOffset={1000}>
           <Popup className="text-slate-900 font-serif">
             <b>{data.主角.姓名}</b><br/>
             {data.主角.所在地}<br/>
             ({playerPos.x}, {playerPos.y})
           </Popup>
        </Marker>

        {/* Waypoints */}
        {Object.entries(waypoints).map(([name, wp]) => (
           <Marker 
             key={name} 
             position={[flipY(wp.坐标.y), wp.坐标.x]} 
             icon={getWPIcon(wp.类型)}
           >
             <Popup className="text-slate-900 font-serif min-w-[200px]">
               <b className="text-base">{name}</b>
               <div className="text-xs text-slate-500 mb-1">{wp.类型} {wp.临时 ? '(临时)' : ''}</div>
               <p className="text-sm">{wp.概况 || '无描述'}</p>
               <div className="text-xs text-slate-400 mt-2 text-right">({wp.坐标.x}, {wp.坐标.y})</div>
             </Popup>
           </Marker>
        ))}
      </MapContainer>
      
      {/* Overlay Info */}
      <div className="absolute top-4 right-4 bg-slate-900/80 p-3 rounded border border-slate-700 backdrop-blur z-[10000]">
         <h4 className="font-cinzel text-blue-300 border-b border-slate-600 mb-2 pb-1 text-sm">当前位置</h4>
         <div className="text-lg font-bold">{data.主角.所在地}</div>
         <div className="text-sm font-mono text-slate-400">X: {playerPos.x} | Y: {playerPos.y}</div>
      </div>
    </div>
  );
};
