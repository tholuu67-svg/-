import React from 'react';
import { Character } from '../../types';
import { ProgressBar } from '../ui/ProgressBar';
import * as Lucide from 'lucide-react';

interface StatusViewProps {
  character: Character;
}

export const StatusView: React.FC<StatusViewProps> = ({ character }) => {
  // Helper to safely get nested objects
  const jobs = character.职业 || {};
  const skills = character.技能列表 || {};
  const buffs = character.当前状态 || {};
  const stats = character.能力 || {};
  const training = character.历练进度 || {};
  const equip = character.装备 || {};

  const getTierColor = (tier: string = '普通') => {
    switch (tier) {
      case '精良': return 'text-blue-400';
      case '稀有': return 'text-purple-400';
      case '史诗': return 'text-amber-500';
      case '传奇': return 'text-pink-500';
      default: return 'text-slate-400';
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 animate-fadeIn">
      {/* Column 1: Core Stats & Vitals */}
      <div className="space-y-6">
        {/* Header Card */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg backdrop-blur-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 p-2 opacity-10 group-hover:opacity-20 transition-opacity">
            <Lucide.User size={80} />
          </div>
          <h2 className="text-2xl font-bold font-cinzel text-blue-300 mb-1">{character.姓名}</h2>
          <div className="flex flex-wrap gap-2 text-sm text-slate-400 mb-4">
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">{character.种族 || '未知种族'}</span>
            <span className="bg-slate-800 px-2 py-0.5 rounded border border-slate-700">{character.公会信息?.所属公会 || '无公会'} ({character.公会信息?.公会阶级 || '无'})</span>
            <span className="flex items-center gap-1"><Lucide.MapPin size={12} /> {character.所在地}</span>
          </div>
          
          {/* Jobs */}
          <div className="mb-4">
             {Object.entries(jobs).map(([name, job]) => (
               <div key={name} className="mb-2">
                 <div className="flex justify-between text-xs mb-1">
                   <span className="font-bold text-blue-200">{name} Lv.{job.当前等级}</span>
                   <span className="text-slate-500">{job.当前经验}/{job.升级所需} XP</span>
                 </div>
                 <div className="h-1.5 w-full bg-slate-800 rounded-full">
                   <div className="h-full bg-blue-500 rounded-full" style={{ width: `${Math.min(100, (job.当前经验 / job.升级所需) * 100)}%` }}></div>
                 </div>
               </div>
             ))}
          </div>

          <div className="h-px bg-gradient-to-r from-transparent via-slate-600 to-transparent my-4"></div>

          {/* Vitals */}
          <div className="space-y-1">
            <ProgressBar label="生命值" current={character.生命值.当前值} max={character.生命值.最大值} colorClass="bg-red-500" />
            <ProgressBar label="护甲值" current={character.护甲值?.当前值 || 0} max={character.护甲值?.最大值 || 0} colorClass="bg-blue-400" />
            <ProgressBar label="魔力值" current={character.魔力值?.当前值 || 0} max={character.魔力值?.最大值 || 0} colorClass="bg-purple-500" />
            <ProgressBar label="信仰" current={character.信仰力值?.当前值 || 0} max={character.信仰力值?.最大值 || 0} colorClass="bg-yellow-200" />
            <ProgressBar label="体力" current={character.体力值?.当前值 || 0} max={character.体力值?.最大值 || 0} colorClass="bg-emerald-400" />
          </div>
        </div>

        {/* Attributes Radar/Grid */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg">
          <h3 className="text-lg font-cinzel text-blue-300 mb-4 flex items-center gap-2">
            <Lucide.Activity size={18} /> 基础能力
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {Object.entries(stats).map(([key, val]) => (
              <div key={key} className="bg-slate-800/50 p-2 rounded border border-slate-700/50">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-slate-300">{key}</span>
                  <span className="text-xl font-bold text-blue-400">{val}</span>
                </div>
                <div className="text-[10px] text-slate-500 mb-1">历练进度</div>
                <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                  <div className="h-full bg-green-400" style={{ width: `${Math.min(100, training[key] || 0)}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Column 2: Equipment, Skills, Buffs */}
      <div className="space-y-6">
        {/* Equipment */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg">
          <h3 className="text-lg font-cinzel text-blue-300 mb-4 flex items-center gap-2">
            <Lucide.Shield size={18} /> 装备
          </h3>
          <div className="space-y-3">
             {/* Iterate major slots */}
             {['武器', '防具', '饰品'].map(cat => {
                const section = equip[cat];
                if (!section) return null;
                return Object.entries(section).map(([key, item]: [string, any]) => (
                  <div key={key} className="flex items-start gap-3 bg-slate-800/40 p-2 rounded border border-slate-700/50 hover:border-slate-500 transition-colors">
                     <div className="mt-1"><Lucide.Sword size={16} className="text-slate-500"/></div>
                     <div className="flex-1">
                       <div className="flex justify-between">
                         <span className={`font-bold ${getTierColor(item.tier)}`}>{item.name || key}</span>
                         <span className="text-xs border border-slate-600 rounded px-1 text-slate-400">{item.tier || '普通'}</span>
                       </div>
                       <p className="text-xs text-slate-400 mt-1 italic">{item.description}</p>
                       {item.special_effects && (
                         <p className="text-xs text-pink-400 mt-1">✨ {typeof item.special_effects === 'string' ? item.special_effects : Object.entries(item.special_effects).map(([k,v])=>`${k}: ${v}`).join(', ')}</p>
                       )}
                     </div>
                  </div>
                ));
             })}
          </div>
        </div>

        {/* Skills */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg">
          <h3 className="text-lg font-cinzel text-blue-300 mb-4 flex items-center gap-2">
            <Lucide.Zap size={18} /> 技能列表
          </h3>
          <div className="space-y-2">
            {Object.entries(skills).map(([name, skill]) => (
              <details key={name} className="group bg-slate-800/30 rounded border border-slate-700/50 open:bg-slate-800/60 transition-colors">
                <summary className="flex justify-between items-center p-2 cursor-pointer list-none select-none">
                  <div className="flex items-center gap-2">
                    <span className="text-blue-200 font-bold">{name}</span>
                    <span className="text-xs bg-slate-900 text-slate-400 px-1.5 py-0.5 rounded">{skill.level}</span>
                  </div>
                  <span className="text-xs text-slate-500 group-open:rotate-90 transition-transform">›</span>
                </summary>
                <div className="px-3 pb-3 pt-1 text-sm text-slate-300 border-t border-slate-700/50 mt-1">
                  <p className="italic text-slate-400 mb-2">{skill.description}</p>
                  <div className="flex justify-between items-center text-xs">
                     <span>消耗: <span className="text-red-300">{skill.cost || '无'}</span></span>
                     <span>熟练: {skill.熟练度}/100</span>
                  </div>
                  <div className="h-1 w-full bg-slate-900 rounded-full mt-1">
                     <div className="h-full bg-purple-500" style={{ width: `${Math.min(100, skill.熟练度)}%` }}></div>
                  </div>
                </div>
              </details>
            ))}
            {Object.keys(skills).length === 0 && <div className="text-slate-500 text-sm">暂无技能</div>}
          </div>
        </div>

        {/* Buffs */}
        <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg">
           <h3 className="text-lg font-cinzel text-blue-300 mb-4 flex items-center gap-2">
            <Lucide.Sparkles size={18} /> 当前状态
          </h3>
          <div className="flex flex-wrap gap-2">
             {Object.entries(buffs).map(([name, buff]) => (
               <div key={name} className="bg-slate-800 border border-slate-600 rounded px-3 py-2 text-sm flex flex-col min-w-[120px]">
                 <div className="flex justify-between mb-1">
                   <span className="font-bold text-amber-200">{name}</span>
                   <span className="text-[10px] bg-slate-950 px-1 rounded">{buff.type}</span>
                 </div>
                 <span className="text-xs text-slate-400">{buff.description}</span>
               </div>
             ))}
             {Object.keys(buffs).length === 0 && <div className="text-slate-500 text-sm">状态良好，无特殊效果。</div>}
          </div>
        </div>

      </div>
    </div>
  );
};
