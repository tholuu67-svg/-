import React, { useState } from 'react';
import { StatData, Character, Enemy } from '../../types';
import * as Lucide from 'lucide-react';
import { ProgressBar } from '../ui/ProgressBar';

interface WorldViewProps {
  data: StatData;
}

export const WorldView: React.FC<WorldViewProps> = ({ data }) => {
  const [activeTab, setActiveTab] = useState<'relations' | 'enemies'>('relations');
  const relations = data.关系列表 || {};
  const enemies = data.敌人列表 || {};

  const renderCharacterCard = (name: string, char: Character | Enemy, isEnemy: boolean) => {
    return (
      <div key={name} className="bg-slate-900/90 border border-slate-700 rounded-lg overflow-hidden shadow-xl hover:shadow-2xl transition-shadow group">
        <div className={`h-2 ${isEnemy ? 'bg-red-600' : 'bg-blue-600'}`}></div>
        <div className="p-5">
          <div className="flex justify-between items-start mb-3">
            <div>
              <h3 className="text-xl font-bold text-slate-200 flex items-center gap-2">
                {char.姓名}
                {char.is_companion && <Lucide.Star size={16} className="text-yellow-400 fill-yellow-400" />}
                {char.在场 && <span className="text-[10px] bg-green-900 text-green-300 px-2 py-0.5 rounded-full border border-green-700">在场</span>}
              </h3>
              <p className="text-sm text-slate-400">{char.种族} | {(isEnemy ? (char as Enemy).类型 : Object.keys(char.职业 || {}).join('/'))}</p>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-500 block">{char.所在地 || '位置未知'}</span>
            </div>
          </div>

          <div className="space-y-3 mb-4">
             {/* Vitals Mini */}
             <div className="flex gap-2 text-xs items-center">
                <Lucide.Heart size={14} className="text-red-500" />
                <div className="w-full bg-slate-800 rounded-full h-2">
                   <div className="bg-red-500 h-2 rounded-full" style={{ width: `${(char.生命值.当前值 / char.生命值.最大值) * 100}%` }}></div>
                </div>
             </div>
             
             {isEnemy && char.护甲值 && (
                <div className="flex gap-2 text-xs items-center">
                  <Lucide.Shield size={14} className="text-blue-500" />
                  <div className="w-full bg-slate-800 rounded-full h-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${(char.护甲值.当前值 / char.护甲值.最大值) * 100}%` }}></div>
                  </div>
               </div>
             )}
          </div>

          <div className="bg-slate-950/50 p-3 rounded text-sm text-slate-400 mb-3 italic border border-slate-800">
             {isEnemy ? (char as Enemy).备注 : char.身份背景}
          </div>

          {!isEnemy && (
            <div className="grid grid-cols-2 gap-3 mb-3">
              <div className="bg-slate-800/50 p-2 rounded text-center">
                <div className="text-xs text-slate-500">好感度</div>
                <div className="text-pink-400 font-bold">{Object.values(char.好感度 || {}).reduce((a, b) => a + b, 0)}</div>
              </div>
              <div className="bg-slate-800/50 p-2 rounded text-center">
                <div className="text-xs text-slate-500">信任度</div>
                <div className="text-blue-400 font-bold">{Object.values(char.信任度 || {}).reduce((a, b) => a + b, 0)}</div>
              </div>
            </div>
          )}

          {!isEnemy && char.重要记忆 && Object.keys(char.重要记忆).length > 0 && (
             <details className="text-sm text-slate-400">
               <summary className="cursor-pointer hover:text-blue-300 transition-colors">重要记忆</summary>
               <ul className="mt-2 space-y-1 list-disc list-inside text-xs text-slate-500">
                 {Object.entries(char.重要记忆).map(([k, v]) => (
                   <li key={k}><span className="text-slate-300">{k}:</span> {v}</li>
                 ))}
               </ul>
             </details>
          )}

           {/* Enemy Abilities or Stats */}
           {isEnemy && char.能力 && (
             <div className="grid grid-cols-3 gap-1 text-xs text-slate-500 mt-2">
                {Object.entries(char.能力).map(([k, v]) => (
                   <div key={k} className="bg-slate-800 px-1 py-0.5 rounded text-center">{k}: {v}</div>
                ))}
             </div>
           )}
        </div>
      </div>
    );
  };

  return (
    <div className="animate-fadeIn">
      {/* Tabs */}
      <div className="flex gap-4 border-b border-slate-700 mb-6">
        <button 
          onClick={() => setActiveTab('relations')}
          className={`pb-2 px-4 font-cinzel transition-colors ${activeTab === 'relations' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-slate-500 hover:text-slate-300'}`}
        >
          关系者 ({Object.keys(relations).length})
        </button>
        <button 
          onClick={() => setActiveTab('enemies')}
          className={`pb-2 px-4 font-cinzel transition-colors ${activeTab === 'enemies' ? 'text-red-500 border-b-2 border-red-500' : 'text-slate-500 hover:text-slate-300'}`}
        >
          敌对者 ({Object.keys(enemies).length})
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
         {activeTab === 'relations' && Object.entries(relations).map(([name, char]) => renderCharacterCard(name, char, false))}
         {activeTab === 'enemies' && Object.entries(enemies).map(([name, char]) => renderCharacterCard(name, char as Enemy, true))}
         
         {activeTab === 'relations' && Object.keys(relations).length === 0 && <p className="text-slate-500 col-span-full text-center">暂无关系者信息</p>}
         {activeTab === 'enemies' && Object.keys(enemies).length === 0 && <p className="text-slate-500 col-span-full text-center">暂无已知敌人</p>}
      </div>
    </div>
  );
};
