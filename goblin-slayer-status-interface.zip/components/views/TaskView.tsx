import React from 'react';
import { StatData, Task } from '../../types';
import * as Lucide from 'lucide-react';

interface TaskViewProps {
  data: StatData;
}

export const TaskView: React.FC<TaskViewProps> = ({ data }) => {
  const activeTasks = data.主角.任务日志?.进行中 || {};
  const completedTasks = data.主角.任务日志?.已完成 || {};

  const renderTask = (name: string, task: Task | string, isCompleted: boolean) => {
    // Handle simplified string tasks or full object tasks
    const description = typeof task === 'string' ? task : task.description;
    const type = typeof task === 'object' ? task.类型 : '普通';
    const target = typeof task === 'object' ? task.当前目标 : '';
    const progress = typeof task === 'object' ? task.进度说明 : '';
    const reward = typeof task === 'object' ? (isCompleted ? task.获得奖励 : task.奖励预览) : '';
    const rating = typeof task === 'object' && isCompleted ? task.完成评价 : '';

    return (
      <div key={name} className={`border ${isCompleted ? 'border-green-800/50 bg-green-900/10' : 'border-amber-700/50 bg-amber-900/10'} rounded-lg p-4 mb-3 transition-all hover:border-opacity-100`}>
        <div className="flex justify-between items-start mb-2">
          <div className="flex items-center gap-2">
            {isCompleted ? <Lucide.CheckCircle2 className="text-green-500" size={20} /> : <Lucide.Circle className="text-amber-500" size={20} />}
            <h4 className={`font-bold text-lg ${isCompleted ? 'text-slate-400 line-through' : 'text-slate-200'}`}>{name}</h4>
          </div>
          <span className="text-xs px-2 py-1 rounded bg-slate-800 border border-slate-700">{type}</span>
        </div>
        
        <div className="pl-7 space-y-1 text-sm">
          {description && <p className="text-slate-400 italic mb-2">{description}</p>}
          
          {!isCompleted && target && (
            <div className="flex gap-2">
              <span className="text-slate-500 font-bold min-w-[40px]">目标:</span>
              <span className="text-slate-300">{target}</span>
            </div>
          )}
          
          {!isCompleted && progress && (
            <div className="flex gap-2">
              <span className="text-slate-500 font-bold min-w-[40px]">进度:</span>
              <span className="text-blue-300">{progress}</span>
            </div>
          )}

          {isCompleted && rating && (
             <div className="flex gap-2">
             <span className="text-slate-500 font-bold min-w-[40px]">评价:</span>
             <span className="text-yellow-400">{rating}</span>
           </div>
          )}
          
          {reward && (
            <div className="flex gap-2 mt-2 pt-2 border-t border-slate-700/50">
              <span className="text-slate-500 font-bold min-w-[40px]">{isCompleted ? '获得:' : '奖励:'}</span>
              <span className="text-emerald-400">{reward}</span>
            </div>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fadeIn">
      <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg min-h-[500px]">
        <h3 className="text-xl font-cinzel text-amber-500 mb-4 flex items-center gap-2 border-b border-amber-900/50 pb-2">
          <Lucide.ScrollText size={24} /> 进行中的任务
        </h3>
        <div className="space-y-2">
          {Object.entries(activeTasks).length > 0 ? (
            Object.entries(activeTasks).map(([name, task]) => renderTask(name, task, false))
          ) : (
            <div className="text-center text-slate-600 py-10">当前没有活跃的任务</div>
          )}
        </div>
      </div>

      <div className="bg-slate-900/80 border border-slate-700 rounded-lg p-5 shadow-lg min-h-[500px]">
        <h3 className="text-xl font-cinzel text-slate-400 mb-4 flex items-center gap-2 border-b border-slate-800 pb-2">
          <Lucide.BookCheck size={24} /> 冒险记录 (已完成)
        </h3>
        <div className="space-y-2 opacity-80">
          {Object.entries(completedTasks).length > 0 ? (
            Object.entries(completedTasks).map(([name, task]) => renderTask(name, task, true))
          ) : (
            <div className="text-center text-slate-600 py-10">尚无完成记录</div>
          )}
        </div>
      </div>
    </div>
  );
};
